if (FML.isModLoaded("Mekanism")) {
    NEI.override("Mekanism:GasTank", [100]);
    NEI.override("Mekanism:*PlasticBlock", [0]);
    NEI.override("Mekanism:Balloon", [0]);
    NEI.override("Mekanism:GlowPanel", [0]);
}