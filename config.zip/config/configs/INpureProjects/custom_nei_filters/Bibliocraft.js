if (FML.isModLoaded("BiblioCraft") && Bibliocraft_enabled) {
    NEI.override("BiblioCraft:*", [0]);
}